import UIKit

//1
var generatedArr: [Int] = []
let generatedCount = 10

while generatedArr.count < generatedCount {
    let randomInt = Int.random(in: 0...generatedCount)
    generatedArr.append(randomInt)
}

print("Исходный массив \(generatedArr)")

var min = generatedArr[0]
var minIndex = 0
var max = generatedArr[0]
var maxIndex = 0

generatedArr.enumerated().forEach { (index, element) in
    if element < min {
        min = element
        minIndex = index
    }
    if element > max {
        max = element
        maxIndex = index
    }
}

generatedArr[minIndex] = max
generatedArr[maxIndex] = min

print("Min \(min), max \(max)")
print("Полученный массив \(generatedArr)")


//2

let alphabet = "abcdefghigklmnopqrstuvwxyz"
let generatedLength = 10

var arr1: [Character] = []
var arr2: [Character] = []

for _ in 0...generatedLength {
    arr1.append(getRandomCharacter())
    arr2.append(getRandomCharacter())
}

func getRandomCharacter() -> Character {
    guard let ch = alphabet.randomElement() else { return "a" }
    return ch
}

var commonCharacters: Set<Character> = []

for firstItem in arr1 {
    for secondItem in arr2 {
        if firstItem == secondItem {
            commonCharacters.insert(firstItem)
        }
    }
}

print("Первый массив символов \(arr1)")
print("Второй массив символов \(arr2)")
print("Общее множество \(commonCharacters)")


//3

var auth: Dictionary<String, String> = [:]
auth["Maksim"] = "Ghdnshd"
auth["Aleksandr"] = "gfhsjdyfhgtd"
auth["Oleg"] = "Hgndkeakdjq"
auth["Denis"] = "Fj12"
var answerValue: [String] = []

for item in auth {
    if item.value.count >= 10 {
        answerValue.append(item.key)
    }
}

print("У этих пользователей пароль от 10 символов \(answerValue)")
